# distance-transform prompts
from __future__ import annotations

import numpy as np
import torch
from scipy.ndimage import distance_transform_edt, binary_erosion


class DSRefineSampler:
    def __init__(self, num_points: int = 40, center_ratio: float = 0.25,
                 boundary_ratio: float = 0.50, negative_ratio: float = 0.25):
        if num_points <= 0:
            raise ValueError('num_points must be positive.')
        self.num_points = int(num_points)
        self.center_ratio = float(center_ratio)
        self.boundary_ratio = float(boundary_ratio)
        self.negative_ratio = float(negative_ratio)
        self.num_center, self.num_boundary, self.num_negative = self._split_num_points(self.num_points)

    def _split_num_points(self, num_points: int):
        n_center = max(1, int(round(num_points * self.center_ratio)))
        n_boundary = max(1, int(round(num_points * self.boundary_ratio)))
        n_negative = num_points - n_center - n_boundary
        if n_negative <= 0:
            n_negative = 1
            if n_boundary > n_center:
                n_boundary -= 1
            else:
                n_center -= 1
        # small rounding fix
        while n_center + n_boundary + n_negative < num_points:
            n_boundary += 1
        while n_center + n_boundary + n_negative > num_points:
            if n_boundary > 1:
                n_boundary -= 1
            elif n_center > 1:
                n_center -= 1
            else:
                n_negative -= 1
        return n_center, n_boundary, n_negative

    @staticmethod
    def _topk_points(scores: np.ndarray, k: int, largest: bool = True) -> np.ndarray:
        valid = np.isfinite(scores)
        ys, xs = np.where(valid)
        if len(xs) == 0:
            h, w = scores.shape
            xs = np.random.randint(0, w, size=k)
            ys = np.random.randint(0, h, size=k)
            return np.stack([xs, ys], axis=1).astype(np.float32)

        vals = scores[ys, xs]
        order = np.argsort(vals)
        if largest:
            order = order[::-1]
        if len(order) >= k:
            order = order[:k]
        else:
            order = np.random.choice(order, size=k, replace=True)
        return np.stack([xs[order], ys[order]], axis=1).astype(np.float32)

    def _sample_one(self, mask_np: np.ndarray) -> np.ndarray:
        m = mask_np > 0.5
        h, w = m.shape
        if m.sum() == 0:
            xs = np.random.randint(0, w, size=self.num_points)
            ys = np.random.randint(0, h, size=self.num_points)
            return np.stack([xs, ys], axis=1).astype(np.float32)

        d_pos = distance_transform_edt(m)
        d_neg = distance_transform_edt(~m)
        eroded = binary_erosion(m, iterations=1)
        boundary = m ^ eroded
        if boundary.sum() == 0:
            boundary = m

        center_scores = np.where(m, d_pos, -np.inf)
        # foreground contour
        boundary_scores = np.where(boundary, d_pos, np.inf)
        neg_scores = np.where(~m, d_neg, -np.inf)

        p_center = self._topk_points(center_scores, self.num_center, largest=True)
        p_boundary = self._topk_points(boundary_scores, self.num_boundary, largest=False)
        p_negative = self._topk_points(neg_scores, self.num_negative, largest=True)
        return np.concatenate([p_center, p_boundary, p_negative], axis=0).astype(np.float32)

    def __call__(self, mask: torch.Tensor, num_points: int | None = None) -> torch.Tensor:
        old = None
        if num_points is not None and int(num_points) != self.num_points:
            old = (self.num_points, self.num_center, self.num_boundary, self.num_negative)
            self.num_points = int(num_points)
            self.num_center, self.num_boundary, self.num_negative = self._split_num_points(self.num_points)

        if mask.dim() == 3:
            mask = mask.unsqueeze(1)
        if mask.dim() != 4:
            raise ValueError(f'mask must be Bx1xHxW or BxHxW, got {tuple(mask.shape)}')
        masks = mask.detach().float().cpu().numpy()
        pts = [self._sample_one(masks[b, 0]) for b in range(masks.shape[0])]
        out = torch.from_numpy(np.stack(pts, axis=0)).to(mask.device).float()

        if old is not None:
            self.num_points, self.num_center, self.num_boundary, self.num_negative = old
        return out
