# LoRA for SAM q/v projection
import math
from typing import Iterable

import torch
import torch.nn as nn


class QVLoRAQKVLinear(nn.Module):
    def __init__(self, base: nn.Linear, r: int = 4, alpha: int = 8, dropout: float = 0.0):
        super().__init__()
        if r <= 0:
            raise ValueError('lora rank must be > 0')
        if base.out_features % 3 != 0:
            raise ValueError('SAM qkv projection should have 3 * dim output features')

        self.base = base
        self.r = int(r)
        self.alpha = int(alpha)
        self.scaling = float(alpha) / float(r)
        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
        dim = base.out_features // 3

        # Only query and value get low-rank deltas. Key stays frozen.
        self.lora_q_A = nn.Parameter(torch.zeros(self.r, base.in_features))
        self.lora_q_B = nn.Parameter(torch.zeros(dim, self.r))
        self.lora_v_A = nn.Parameter(torch.zeros(self.r, base.in_features))
        self.lora_v_B = nn.Parameter(torch.zeros(dim, self.r))

        nn.init.kaiming_uniform_(self.lora_q_A, a=math.sqrt(5))
        nn.init.zeros_(self.lora_q_B)
        nn.init.kaiming_uniform_(self.lora_v_A, a=math.sqrt(5))
        nn.init.zeros_(self.lora_v_B)

        for p in self.base.parameters():
            p.requires_grad = False

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.base(x)
        x_drop = self.dropout(x)
        dq = (x_drop @ self.lora_q_A.t()) @ self.lora_q_B.t()
        dv = (x_drop @ self.lora_v_A.t()) @ self.lora_v_B.t()
        dk = torch.zeros_like(dq)
        return out + self.scaling * torch.cat([dq, dk, dv], dim=-1)


# old name kept so previous imports do not break
LoRALinear = QVLoRAQKVLinear


def inject_lora_to_qv(image_encoder: nn.Module, r: int = 4, alpha: int = 8, dropout: float = 0.0) -> nn.Module:
    for _, module in image_encoder.named_modules():
        if hasattr(module, 'qkv') and isinstance(module.qkv, nn.Linear):
            module.qkv = QVLoRAQKVLinear(module.qkv, r=r, alpha=alpha, dropout=dropout)
    return image_encoder


def mark_only_lora_as_trainable(model: nn.Module, extra_keywords: Iterable[str] = ()): 
    keep = tuple(extra_keywords) + ('lora_',)
    for name, p in model.named_parameters():
        p.requires_grad = any(k in name for k in keep)
    return model
