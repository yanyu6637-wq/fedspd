# FedSPD

这个仓库主要用于联邦小样本医学图像分割实验。代码包含本地客户端训练、服务端聚合、结构化提示生成、LoRA 适配和若干联邦对比方法。

## 目录

```text
configs/      配置文件
models/       模型结构
datasets/     数据读取
federated/    联邦训练主流程
scripts/      常用运行脚本
```

## 使用

先在配置文件里改数据路径和权重路径：

```bash
configs/fedspd.yaml
```

主方法训练：

```bash
python federated/train_FedSPD_bs4.py --config configs/fedspd.yaml --algorithm fedspd
```

对比方法：

```bash
bash scripts/run_comparison.sh
```

敏感性分析：

```bash
bash scripts/run_sensitivity_np.sh
bash scripts/run_sensitivity_nt.sh
```

数据需要提前按客户端整理好。代码默认读取已经划分好的客户端文件夹。
